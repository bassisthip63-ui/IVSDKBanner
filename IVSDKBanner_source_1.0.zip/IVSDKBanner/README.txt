IVSDKBanner 1.0  -  "IV-SDK .NET is running" message for GTA IV
================================================================

What it does
------------
Once per game launch, a few seconds after you're in control, a subtitle at the bottom of the screen shows which
IV-SDK .NET and GTA IV versions are running, for example:
    IV-SDK .NET v1.9.1.0 is running
    GTAIV.exe v1.0.8.0
Both versions are read live from the files, so it's always right for your setup. On GTA IV 1.2.0.59 it adds
"(Unofficial 1.2.0.59 Beta)", since IV-SDK .NET only runs there with the unofficial fork. The same line also goes
to the IV-SDK .NET console (F4) and log.

It waits until no subtitle, help message or conversation is on screen, so it never covers dialogue, mission
text or another mod's message,
and it doesn't change any of the game's text.

Requirements
------------
IV-SDK .NET (by ItsClonkAndre). Works on any GTA IV version IV-SDK .NET runs on.

Install
-------
Copy IVSDKBanner.ivsdk.dll into GTAIV\IVSDKDotNet\scripts. Delete it to uninstall.

Build it yourself (optional)
----------------------------
Put the source folder inside your GTA IV folder (next to GTAIV.exe) and double-click build.bat. It uses the C#
compiler built into Windows (.NET Framework 4), compiles against your IVSDKDotNetWrapper.dll, and copies
IVSDKBanner.ivsdk.dll into IVSDKDotNet\scripts.

Credits and licence
-------------------
By bassisthip63-ui, with Claude (Anthropic). MIT License (LICENSE).
IV-SDK .NET by ItsClonkAndre. Not affiliated with Rockstar Games or Take-Two Interactive.
