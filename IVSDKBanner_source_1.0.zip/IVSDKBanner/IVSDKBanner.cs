// IVSDKBanner 1.0 - an IV-SDK .NET script. Copyright (c) 2026 bassisthip63-ui. MIT License (see LICENSE).
// Shows a subtitle (bottom of the screen) once per game session, after the player is in control:
//     IV-SDK .NET v1.9.1.0 is running
//     GTAIV.exe v1.2.0.59
// Both versions are read at runtime: the IV-SDK version from IVSDKDotNetWrapper.dll, the game version from GTAIV.exe.
// It uses IV-SDK's own IVGame.ShowSubtitleMessage, which hands the text to the game as a literal string, so no game
// text is overwritten (an earlier version replaced the text of PLACEHOLDER_1, which only has room for 35 characters).
//
// Written for the C# 5 compiler that ships with .NET Framework 4 (csc.exe), so it can be built on any Windows PC.

using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using IVSDKDotNet;
using N = IVSDKDotNet.Native.Natives;

[assembly: AssemblyTitle("IVSDKBanner")]
[assembly: AssemblyCompany("bassisthip63-ui")]
[assembly: AssemblyProduct("IVSDKBanner")]
[assembly: AssemblyCopyright("Copyright (c) 2026 bassisthip63-ui. MIT License.")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyDescription("Shows which IV-SDK .NET and GTA IV versions are running, once per session")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: Guid("5b1f4c2e-8f0a-4d6b-9c3e-2a7d61e0b9a4")]

namespace IVSDKBanner
{
    public class Main : Script
    {
        const uint ShowMs = 6000;                  // how long the subtitle stays up
        const int DelayMs = 4000;                  // wait this long after the player is first in control

        bool shown;
        DateTime readySince = DateTime.MinValue;
        string message;

        public Main()
        {
            Tick += Main_Tick;
        }

        static string Ver(Version v)
        {
            return v == null ? "?" : string.Format("{0}.{1}.{2}.{3}", v.Major, v.Minor, v.Build, v.Revision);
        }

        static string BuildMessage()
        {
            string sdk = "?";
            string game = "?";
            try { sdk = Ver(typeof(Script).Assembly.GetName().Version); } catch { }
            try { game = FileVersionInfo.GetVersionInfo(Process.GetCurrentProcess().MainModule.FileName).FileVersion; } catch { }
            if (game != null) game = game.Replace(", ", ".").Replace(',', '.');
            // IV-SDK .NET on 1.2.0.59 can only be the unofficial fork, so say so
            string extra = game == "1.2.0.59" ? " (Unofficial 1.2.0.59 Beta)" : "";
            return "IV-SDK .NET v" + sdk + extra + " is running~n~GTAIV.exe v" + game;
        }

        void Main_Tick(object sender, EventArgs e)
        {
            if (shown) return;
            try
            {
                int player = (int)N.GET_PLAYER_ID();
                bool ready = N.IS_PLAYER_PLAYING(player) && !N.IS_SCREEN_FADED_OUT() && !N.IS_HELP_MESSAGE_BEING_DISPLAYED()
                             && !N.IS_MESSAGE_BEING_DISPLAYED() && !N.IS_SCRIPTED_CONVERSATION_ONGOING();   // never over dialogue or mission text
                if (!ready) { readySince = DateTime.MinValue; return; }
                if (readySince == DateTime.MinValue) { readySince = DateTime.UtcNow; return; }
                if ((DateTime.UtcNow - readySince).TotalMilliseconds < DelayMs) return;

                if (message == null) message = BuildMessage();
                IVGame.ShowSubtitleMessage(message, ShowMs);
                shown = true;
                IVGame.Console.Print("IVSDKBanner: " + message.Replace("~n~", " / "));
            }
            catch (Exception ex)
            {
                shown = true;   // never retry every frame after an error
                IVGame.Console.Print("IVSDKBanner: could not show the banner: " + ex.Message);
            }
        }
    }
}
